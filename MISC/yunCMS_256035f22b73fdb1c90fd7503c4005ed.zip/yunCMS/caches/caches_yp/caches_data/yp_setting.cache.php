<?php
return array (
  'position' => 
  array (
    1 => 
    array (
      'posid' => '9',
      'name' => '全局黄页置顶',
      'point' => '2',
      'num' => '10',
    ),
    2 => 
    array (
      'posid' => '8',
      'name' => '列表置顶',
      'point' => '1',
      'num' => '5',
    ),
  ),
  'ischeck' => '1',
  'isbusiness' => '1',
  'enable_rewrite' => '0',
  'encode_page_cache' => '1',
  'seo_title' => 'PHPCMS企业黄页',
  'seo_keywords' => 'PHPCMS,企业黄页,V9',
  'seo_description' => '',
  'priv' => 
  array (
    2 => 
    array (
      'allowpostverify' => '1',
      12 => '1',
      13 => '1',
      14 => '1',
    ),
    6 => 
    array (
      'allowpostverify' => '1',
      12 => '1',
      13 => '1',
      14 => '1',
    ),
    4 => 
    array (
      'allowpostverify' => '1',
      12 => '1',
      13 => '1',
      14 => '1',
    ),
    5 => 
    array (
      'allowpostverify' => '1',
      12 => '1',
      13 => '1',
      14 => '1',
    ),
  ),
);
?>