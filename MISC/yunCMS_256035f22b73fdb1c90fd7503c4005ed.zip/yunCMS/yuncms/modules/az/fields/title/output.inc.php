	function title($field, $value) {
		$value = htmlspecialchars($value);
		return $value;
	}
