<?php
return array (
  1 => 
  array (
    'id' => 0,
    'title' => '默认模板',
    'dir' => 'com_default',
    'thumb' => IMG_PATH.'yp/demo_default.jpg',
    'aid' => '1549',
    'defaulttpl' => 1,
    'groups' => '2,6,4,5,16,17',
  ),
);
?>