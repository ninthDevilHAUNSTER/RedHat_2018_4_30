<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('UNINSTALL') or exit('Access Denied');

return array('yp_certificate', 'yp_company', 'yp_guestbook', 'yp_relation', 'order', 'member_address', 'comment_relation', 'buycar');
?>