<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'dianping';
$modulename = '点评模块';
$introduce = '点评系统';
$author = 'phpcms Team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>